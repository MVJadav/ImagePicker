//
//  ViewController.swift
//  CameraDemo
//
//  Created by Mehul Jadav on 26/03/20.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func didTakePhoto (button : UIButton) {
        
    }
    
}

